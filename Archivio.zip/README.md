# slides.com_downloader
Simple Chrome / Edge extension that allow to download the pdf from any link of slides.com
